		<!-- footer -->
		<div class="footer">
			<p>Life Stories &copy; <?php echo date('Y'); ?></p>
		</div>
		<!-- // footer -->

	</div>
	<!-- // container -->
</body>
</html>